import React, { Component } from 'react'

export default class Stories extends Component {
    render() {
        return (
            <header className="stories">
                Stories
            </header>
        )
    }
}
