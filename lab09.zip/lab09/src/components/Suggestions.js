import React, { Component } from 'react'

export default class Suggestions extends Component {
    render() {
        return (
            <div className="suggestions">
                <p className="suggestion-text">Suggestions for you</p>
                <div>
                    Suggestions
                </div>
            </div>
        )
    }
}
